export const products = [
  {
    id: 1,
    name: "Premium Wireless Headphones",
    price: 299.99,
    description: "High-quality wireless headphones with noise cancellation",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e",
    category: "Electronics"
  },
  {
    id: 2,
    name: "Smart Watch Pro",
    price: 199.99,
    description: "Advanced smartwatch with health tracking features",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30",
    category: "Electronics"
  },
  {
    id: 3,
    name: "Leather Laptop Bag",
    price: 89.99,
    description: "Stylish and durable leather laptop bag",
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62",
    category: "Accessories"
  },
  {
    id: 4,
    name: "Wireless Mouse",
    price: 49.99,
    description: "Ergonomic wireless mouse for comfortable use",
    image: "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46",
    category: "Electronics"
  }
];